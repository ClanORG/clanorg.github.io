import { GoogleGenAI, Type } from "@google/genai";
import { Movie, AppConfig } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const searchMoviesWithAI = async (query: string): Promise<Movie[]> => {
  if (!apiKey) {
    console.error("API Key is missing");
    return [];
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Generate a list of 10 fictional or real movies/shows that strictly match this search query: "${query}". 
      Return the data in JSON format. 
      For images, use strict placeholder URLs: 
      - thumbnailUrl: "https://picsum.photos/seed/{unique_seed_1}/400/230" (landscape)
      - posterUrl: "https://picsum.photos/seed/{unique_seed_1}/600/900" (high res vertical portrait)
      - coverUrl: "https://picsum.photos/seed/{unique_seed_2}/1920/1080" (high res hero)
      - videoUrl: "https://unlimplay.com/play.php/embed/movie/1979" (default video link)
      Replace {unique_seed} with a random string related to the movie title.
      Ensure genres are relevant (Action, Comedy, Drama, Sci-Fi, Horror, Romance, Documental).
      Rating should be like "TV-MA", "PG-13", "R".
      MatchScore between 70 and 100.
      `,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              thumbnailUrl: { type: Type.STRING },
              posterUrl: { type: Type.STRING },
              coverUrl: { type: Type.STRING },
              videoUrl: { type: Type.STRING },
              genre: { type: Type.ARRAY, items: { type: Type.STRING } },
              duration: { type: Type.STRING },
              rating: { type: Type.STRING },
              matchScore: { type: Type.INTEGER },
              year: { type: Type.INTEGER }
            }
          }
        }
      }
    });

    const text = response.text;
    if (!text) return [];
    
    return JSON.parse(text) as Movie[];
  } catch (error) {
    console.error("Error searching with Gemini:", error);
    return [];
  }
};

interface AICommandResponse {
  action: 'UPDATE_CONFIG' | 'ADD_MOVIE' | 'NONE';
  message: string;
  configPayload?: Partial<AppConfig>;
  moviePayload?: Movie;
}

export const processAICommand = async (
  prompt: string, 
  currentConfig: AppConfig
): Promise<AICommandResponse> => {
  if (!apiKey) return { action: 'NONE', message: "API Key missing." };

  const systemPrompt = `
    You are an expert App Administrator AI for a Netflix Clone. 
    You have full control over the app's configuration (colors, name, logo, layout) and content.
    
    Current Config: ${JSON.stringify(currentConfig)}

    Available Category IDs for 'categoryOrder': ["trends", "new", "us_series", "action", "comedy"].

    Your goal is to interpret the user's natural language request and return a JSON object to execute the change.
    
    If the user wants to change the look, layout, or branding:
    - Return action: "UPDATE_CONFIG"
    - Provide 'configPayload' with ONLY the fields that need changing.
    - Fields available: 
      - appName, logoUrl
      - primaryColor, backgroundColor, secondaryColor, textColor
      - showBillboard (boolean)
      - categoryOrder (array of strings, e.g. ["action", "trends"])
    - Example: "Put action movies first" -> categoryOrder: ["action", "trends", "new", ...]
    - Example: "Make it look like Barbie" -> set primaryColor to pink, background to white/pink.

    If the user wants to add a specific movie or show:
    - Return action: "ADD_MOVIE"
    - Provide 'moviePayload' with a complete Movie object (generate details creatively).
    - Use 'https://picsum.photos/...' for images with unique seeds.
    - posterUrl MUST be 'https://picsum.photos/seed/.../600/900' for high quality.
    - Use 'https://unlimplay.com/play.php/embed/movie/1979' for videoUrl unless specified.
    
    If the user just wants to chat or the request is unclear:
    - Return action: "NONE"
    - Just provide a helpful 'message'.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            action: { type: Type.STRING, enum: ['UPDATE_CONFIG', 'ADD_MOVIE', 'NONE'] },
            message: { type: Type.STRING },
            configPayload: {
              type: Type.OBJECT,
              properties: {
                appName: { type: Type.STRING },
                logoUrl: { type: Type.STRING },
                primaryColor: { type: Type.STRING },
                backgroundColor: { type: Type.STRING },
                secondaryColor: { type: Type.STRING },
                textColor: { type: Type.STRING },
                showBillboard: { type: Type.BOOLEAN },
                categoryOrder: { type: Type.ARRAY, items: { type: Type.STRING } }
              }
            },
            moviePayload: {
               type: Type.OBJECT,
               properties: {
                  id: { type: Type.STRING },
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                  thumbnailUrl: { type: Type.STRING },
                  posterUrl: { type: Type.STRING },
                  coverUrl: { type: Type.STRING },
                  videoUrl: { type: Type.STRING },
                  genre: { type: Type.ARRAY, items: { type: Type.STRING } },
                  duration: { type: Type.STRING },
                  rating: { type: Type.STRING },
                  matchScore: { type: Type.INTEGER },
                  year: { type: Type.INTEGER }
               }
            }
          }
        }
      }
    });

    const text = response.text;
    if(!text) return { action: 'NONE', message: "No response from AI." };
    return JSON.parse(text) as AICommandResponse;

  } catch (error) {
    console.error(error);
    return { action: 'NONE', message: "Error processing AI command." };
  }
};