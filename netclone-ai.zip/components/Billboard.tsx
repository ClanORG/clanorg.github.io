import React from 'react';
import { Play, Info, Plus } from 'lucide-react';
import { Movie } from '../types';

interface BillboardProps {
  movie: Movie;
  onOpenModal: (movie: Movie) => void;
  onPlay: (movie: Movie) => void;
  primaryColor?: string;
}

export const Billboard: React.FC<BillboardProps> = ({ movie, onOpenModal, onPlay, primaryColor }) => {
  return (
    <div className="relative w-full">
      {/* Mobile: Taller Aspect Ratio (Poster Standard 2:3) */}
      <div className="md:hidden relative w-full aspect-[2/3] max-h-[85vh]">
         <img 
            src={movie.posterUrl} 
            alt={movie.title} 
            className="w-full h-full object-cover object-top" 
          />
          {/* Top gradient for navbar visibility */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-transparent h-32"></div>
          
          {/* Bottom gradient for text readability */}
          <div className="absolute bottom-0 left-0 w-full h-2/3 bg-gradient-to-t from-black via-black/40 to-transparent"></div>
          
          <div className="absolute bottom-0 left-0 w-full p-4 flex flex-col items-center justify-end space-y-4 pb-8 z-10">
             <div className="flex flex-wrap justify-center gap-2 text-xs font-medium text-gray-200 drop-shadow-md mb-2">
                {movie.genre.slice(0, 4).map((g, i) => (
                  <span key={i} className="flex items-center">
                    {i > 0 && <span className="mr-2 opacity-50">•</span>}
                    {g}
                  </span>
                ))}
             </div>

             <div className="flex items-center gap-4 w-full justify-center px-4">
                <button className="flex flex-col items-center gap-1 min-w-[60px] text-white hover:text-gray-300 transition">
                   <Plus size={24} />
                   <span className="text-[10px] font-medium">Mi lista</span>
                </button>

                <button 
                  onClick={() => onPlay(movie)}
                  className="bg-white text-black px-6 py-2.5 rounded font-bold flex items-center gap-2 hover:bg-opacity-90 transition text-lg flex-1 justify-center max-w-[160px]"
                >
                  <Play fill="black" size={24} />
                  Reproducir
                </button>

                <button 
                  onClick={() => onOpenModal(movie)}
                  className="flex flex-col items-center gap-1 min-w-[60px] text-white hover:text-gray-300 transition"
                >
                   <Info size={24} />
                   <span className="text-[10px] font-medium">Info</span>
                </button>
             </div>
          </div>
      </div>

      {/* Desktop: Classic 16:9 Billboard */}
      <div className="hidden md:block relative h-[56.25vw] max-h-[85vh] w-full">
        <div className="absolute top-0 left-0 w-full h-full">
          <img 
            src={movie.coverUrl} 
            alt={movie.title} 
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-transparent to-transparent"></div>
          <div className="absolute bottom-0 w-full h-48 bg-gradient-to-t from-black to-transparent"></div>
        </div>

        <div className="absolute top-[30%] left-12 max-w-xl z-10 space-y-6">
          <h1 className="text-6xl font-extrabold drop-shadow-lg tracking-tight">
            {movie.title}
          </h1>
          <p className="text-lg drop-shadow-md line-clamp-3 opacity-90">
            {movie.description}
          </p>
          
          <div className="flex items-center gap-4">
            <button 
              onClick={() => onPlay(movie)}
              className="bg-white text-black px-8 py-3 rounded flex items-center gap-3 hover:bg-opacity-80 transition font-bold text-xl"
            >
              <Play fill="black" size={28} />
              Reproducir
            </button>
            <button 
              onClick={() => onOpenModal(movie)}
              className="bg-gray-500/70 text-white px-8 py-3 rounded flex items-center gap-3 hover:bg-opacity-50 transition font-bold text-xl backdrop-blur-sm"
            >
              <Info size={28} />
              Más información
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};