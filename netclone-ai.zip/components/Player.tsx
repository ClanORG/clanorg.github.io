import React, { useState, useEffect } from 'react';
import { X, RotateCw, Smartphone, Maximize, Minimize, Scaling } from 'lucide-react';

interface PlayerProps {
  url: string;
  onClose: () => void;
}

export const Player: React.FC<PlayerProps> = ({ url, onClose }) => {
  const [isRotated, setIsRotated] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [scaleMode, setScaleMode] = useState<'fit' | 'zoom'>('fit');

  // Auto-activar rotación y fullscreen al cargar en móvil
  useEffect(() => {
    const isMobile = window.innerWidth < 768;
    
    if (isMobile) {
      setIsRotated(true);
      // Intentar fullscreen automático (los navegadores pueden bloquear esto sin interacción directa del usuario)
      enterFullscreen();
    }

    // Listener para cambios de fullscreen
    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  const enterFullscreen = async () => {
    try {
      if (document.documentElement.requestFullscreen) {
        await document.documentElement.requestFullscreen();
      }
    } catch (e) {
      console.log("Fullscreen automático prevenido por el navegador (requiere click)", e);
    }
  };

  const toggleRotation = () => {
    setIsRotated(!isRotated);
  };

  const toggleScale = () => {
    setScaleMode(prev => prev === 'fit' ? 'zoom' : 'fit');
  };

  const toggleFullscreen = async () => {
    if (!document.fullscreenElement) {
        await enterFullscreen();
    } else {
        if (document.exitFullscreen) {
            await document.exitFullscreen();
        }
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black flex items-center justify-center overflow-hidden animate-fade-in touch-none">
      
      {/* Controles Flotantes (Siempre relativos al viewport visual del usuario) 
          Usamos z-index alto y transformaciones para que los controles sigan siendo usables
          incluso cuando el video está rotado.
      */}
      <div 
        className={`absolute top-0 right-0 p-4 md:p-6 flex flex-col gap-3 md:gap-4 z-[120] transition-all duration-500 ${
           isRotated ? 'top-4 right-4' : 'top-4 right-4'
        }`}
      >
        <button 
          onClick={onClose}
          className="bg-red-600/90 text-white p-3 rounded-full hover:bg-red-700 transition shadow-lg border border-white/10 backdrop-blur-md"
        >
          <X size={20} className="md:w-6 md:h-6" />
        </button>

        <button 
            onClick={toggleRotation}
            className="bg-gray-800/80 text-white p-3 rounded-full hover:bg-gray-700 transition shadow-lg border border-white/10 backdrop-blur-md"
            title="Rotar 90º"
        >
            <Smartphone className={`transition-transform duration-300 ${isRotated ? 'rotate-90' : ''}`} size={20} />
        </button>

        <button 
            onClick={toggleScale}
            className="bg-gray-800/80 text-white p-3 rounded-full hover:bg-gray-700 transition shadow-lg border border-white/10 backdrop-blur-md"
            title={scaleMode === 'fit' ? "Rellenar Pantalla (Zoom)" : "Ajustar al borde"}
        >
            <Scaling size={20} className={scaleMode === 'zoom' ? 'text-blue-400' : ''} />
        </button>

        <button 
            onClick={toggleFullscreen}
            className="bg-gray-800/80 text-white p-3 rounded-full hover:bg-gray-700 transition shadow-lg border border-white/10 backdrop-blur-md hidden md:block"
        >
            {isFullscreen ? <Minimize size={24} /> : <Maximize size={24} />}
        </button>
      </div>
      
      {/* Contenedor del Video
          Lógica Actualizada:
          - FIXED: Usamos fixed para ignorar el flujo del documento.
          - 100dvh/100dvw: Unidades dinámicas para evitar problemas con la barra de direcciones móvil.
          - Scale Transform: Si el usuario selecciona 'zoom', escalamos al 130% para comerse las barras negras.
      */}
      <div 
        className={`fixed bg-black shadow-2xl overflow-hidden transition-all duration-500 ease-in-out`}
        style={{
            // Si está rotado, intercambiamos ancho por alto del viewport
            width: isRotated ? '100dvh' : '100dvw',
            height: isRotated ? '100dvw' : '100dvh',
            top: '50%',
            left: '50%',
            transform: `
              translate(-50%, -50%) 
              rotate(${isRotated ? '90deg' : '0deg'}) 
              scale(${scaleMode === 'zoom' ? 1.35 : 1})
            `,
            transformOrigin: 'center center'
        }}
      >
        <iframe 
          src={url} 
          className="w-full h-full border-none" 
          allowFullScreen 
          allow="autoplay; encrypted-media; fullscreen; picture-in-picture"
          title="Video Player"
          referrerPolicy="no-referrer"
          // Bloqueo de anuncios (Popups) manteniendo scripts necesarios para reproducción
          sandbox="allow-forms allow-scripts allow-same-origin allow-presentation"
        />
        
        {/* Capa invisible para evitar interacción con anuncios popup si logran evadir el sandbox (opcional, puede bloquear controles del player nativo si no se tiene cuidado) */}
        {/* <div className="absolute inset-0 pointer-events-none"></div> */}
      </div>
    </div>
  );
};