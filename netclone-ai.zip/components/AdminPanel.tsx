import React, { useState, useRef, useEffect } from 'react';
import { Movie, AppConfig, CategoryDef } from '../types';
import { processAICommand } from '../services/geminiService';
import { X, Save, Trash2, Plus, Image as ImageIcon, Palette, Layout, ArrowUp, ArrowDown, Bot, Send, Loader2, Sparkles, Video } from 'lucide-react';

interface AdminPanelProps {
  movies: Movie[];
  setMovies: (movies: Movie[]) => void;
  config: AppConfig;
  setConfig: (config: AppConfig) => void;
  onClose: () => void;
  categoryDefs: Record<string, CategoryDef>;
}

interface ChatMessage {
  role: 'user' | 'assistant';
  text: string;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ movies, setMovies, config, setConfig, onClose, categoryDefs }) => {
  const [activeTab, setActiveTab] = useState<'content' | 'design' | 'edit'>('content');
  const [editingMovie, setEditingMovie] = useState<Movie | null>(null);

  // --- AI CHAT STATE ---
  const [chatInput, setChatInput] = useState('');
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([
    { role: 'assistant', text: 'Hola, soy tu arquitecto de IA. Pídeme cambiar colores, el nombre de la app, o agregar películas específicas.' }
  ]);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory]);

  // --- CONTENT LOGIC ---
  const createEmptyMovie = (): Movie => ({
    id: `custom-${Date.now()}`,
    title: '',
    description: '',
    thumbnailUrl: 'https://picsum.photos/seed/new/400/230',
    posterUrl: 'https://picsum.photos/seed/new/300/450',
    coverUrl: 'https://picsum.photos/seed/new/1920/1080',
    videoUrl: 'https://unlimplay.com/play.php/embed/movie/1979',
    genre: ['Acción'],
    duration: '2h 0m',
    rating: 'PG-13',
    matchScore: 90,
    year: new Date().getFullYear()
  });

  const handleEdit = (movie: Movie) => {
    setEditingMovie({ ...movie });
    setActiveTab('edit');
  };

  const handleAddNew = () => {
    setEditingMovie(createEmptyMovie());
    setActiveTab('edit');
  };

  const handleDelete = (id: string) => {
    if (window.confirm('¿Estás seguro de que quieres eliminar esta película?')) {
      setMovies(movies.filter(m => m.id !== id));
      if (editingMovie?.id === id) {
        setEditingMovie(null);
        setActiveTab('content');
      }
    }
  };

  const handleSaveMovie = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMovie) return;

    const existingIndex = movies.findIndex(m => m.id === editingMovie.id);
    if (existingIndex >= 0) {
      const updatedMovies = [...movies];
      updatedMovies[existingIndex] = editingMovie;
      setMovies(updatedMovies);
    } else {
      setMovies([editingMovie, ...movies]);
    }
    setActiveTab('content');
  };

  const handleMovieChange = (field: keyof Movie, value: any) => {
    if (!editingMovie) return;
    setEditingMovie({ ...editingMovie, [field]: value });
  };

  // --- DESIGN LOGIC ---
  const handleConfigChange = (field: keyof AppConfig, value: any) => {
    setConfig({ ...config, [field]: value });
  };

  const moveCategory = (index: number, direction: 'up' | 'down') => {
    const newOrder = [...config.categoryOrder];
    if (direction === 'up' && index > 0) {
      [newOrder[index], newOrder[index - 1]] = [newOrder[index - 1], newOrder[index]];
    } else if (direction === 'down' && index < newOrder.length - 1) {
      [newOrder[index], newOrder[index + 1]] = [newOrder[index + 1], newOrder[index]];
    }
    setConfig({ ...config, categoryOrder: newOrder });
  };

  // --- AI HANDLER ---
  const handleAiSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || isAiLoading) return;

    const userMsg = chatInput;
    setChatInput('');
    setChatHistory(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsAiLoading(true);

    const result = await processAICommand(userMsg, config);

    setIsAiLoading(false);
    setChatHistory(prev => [...prev, { role: 'assistant', text: result.message }]);

    if (result.action === 'UPDATE_CONFIG' && result.configPayload) {
        setConfig({ ...config, ...result.configPayload });
    } else if (result.action === 'ADD_MOVIE' && result.moviePayload) {
        // Generate a slightly random ID to avoid collisions if AI repeats
        const newMovie = { ...result.moviePayload, id: `ai-${Date.now()}` };
        setMovies([newMovie, ...movies]);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#141414] text-white overflow-hidden flex flex-col animate-fade-in">
      {/* Header */}
      <div className="flex-none bg-[#181818] border-b border-gray-800 px-4 md:px-8 py-4 flex items-center justify-between">
        <div className="flex items-center gap-6">
           <h1 className="text-2xl font-bold flex items-center gap-3">
              <SettingsIcon /> Panel de Control
           </h1>
           <div className="hidden md:flex bg-[#262626] rounded-full p-1 border border-gray-700">
              <button 
                onClick={() => setActiveTab('content')}
                className={`px-6 py-1.5 rounded-full text-sm font-bold transition ${activeTab === 'content' || activeTab === 'edit' ? 'bg-white text-black' : 'text-gray-400 hover:text-white'}`}
              >
                Contenido
              </button>
              <button 
                onClick={() => setActiveTab('design')}
                className={`px-6 py-1.5 rounded-full text-sm font-bold transition ${activeTab === 'design' ? 'bg-white text-black' : 'text-gray-400 hover:text-white'}`}
              >
                Diseño e IA
              </button>
           </div>
        </div>
        <button onClick={onClose} className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded font-bold flex items-center gap-2">
          <X size={20} /> Salir
        </button>
      </div>

      {/* Mobile Tab Switcher */}
      <div className="md:hidden flex bg-[#181818] border-b border-gray-800">
         <button onClick={() => setActiveTab('content')} className={`flex-1 py-3 text-sm font-bold ${activeTab !== 'design' ? 'text-white border-b-2 border-red-600' : 'text-gray-500'}`}>Contenido</button>
         <button onClick={() => setActiveTab('design')} className={`flex-1 py-3 text-sm font-bold ${activeTab === 'design' ? 'text-white border-b-2 border-red-600' : 'text-gray-500'}`}>Diseño</button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 md:p-8 max-w-[1600px] mx-auto w-full">
        
        {/* --- CONTENT TAB --- */}
        {activeTab === 'content' && (
          <div className="space-y-4">
             <div className="flex justify-between items-center mb-4">
               <h2 className="text-xl font-semibold">Biblioteca de Películas ({movies.length})</h2>
               <button onClick={handleAddNew} className="bg-white text-black px-4 py-2 rounded font-bold flex items-center gap-2 hover:bg-gray-200">
                 <Plus size={20} /> Agregar Nuevo
               </button>
             </div>
             <div className="bg-[#1f1f1f] rounded-lg overflow-hidden border border-gray-800">
                  <table className="w-full text-left">
                    <thead className="bg-[#2a2a2a] text-gray-400 text-xs uppercase">
                      <tr>
                        <th className="p-4">Título</th>
                        <th className="p-4 hidden md:table-cell">Año</th>
                        <th className="p-4 text-right">Acciones</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-800">
                      {movies.map(movie => (
                        <tr key={movie.id} className="hover:bg-[#262626] transition">
                          <td className="p-3 font-medium">{movie.title}</td>
                          <td className="p-3 text-gray-400 hidden md:table-cell">{movie.year}</td>
                          <td className="p-3 text-right space-x-2">
                             <button onClick={() => handleEdit(movie)} className="text-gray-400 hover:text-white p-2">Editar</button>
                             <button onClick={() => handleDelete(movie.id)} className="text-red-500 hover:text-red-400 p-2"><Trash2 size={18} /></button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
             </div>
          </div>
        )}

        {/* --- DESIGN & AI TAB --- */}
        {activeTab === 'design' && (
           <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 h-full">
              
              {/* Left Column: Visual Controls */}
              <div className="space-y-6 overflow-y-auto">
                 {/* Theme Settings */}
                 <div className="bg-[#1f1f1f] p-6 rounded-lg border border-gray-800">
                    <h3 className="text-lg font-bold mb-4 flex items-center gap-2"><Palette size={20}/> Colores y Tema</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                           <label className="block text-xs text-gray-400 uppercase mb-2">Fondo Principal</label>
                           <div className="flex items-center gap-3">
                              <input 
                                type="color" 
                                value={config.backgroundColor} 
                                onChange={(e) => handleConfigChange('backgroundColor', e.target.value)}
                                className="h-10 w-20 rounded cursor-pointer bg-transparent border-none"
                              />
                              <span className="text-sm font-mono">{config.backgroundColor}</span>
                           </div>
                        </div>
                        <div>
                           <label className="block text-xs text-gray-400 uppercase mb-2">Color Primario (Botones)</label>
                           <div className="flex items-center gap-3">
                              <input 
                                type="color" 
                                value={config.primaryColor} 
                                onChange={(e) => handleConfigChange('primaryColor', e.target.value)}
                                className="h-10 w-20 rounded cursor-pointer bg-transparent border-none"
                              />
                              <span className="text-sm font-mono">{config.primaryColor}</span>
                           </div>
                        </div>
                        <div>
                           <label className="block text-xs text-gray-400 uppercase mb-2">Color de Texto</label>
                           <div className="flex items-center gap-3">
                              <input 
                                type="color" 
                                value={config.textColor} 
                                onChange={(e) => handleConfigChange('textColor', e.target.value)}
                                className="h-10 w-20 rounded cursor-pointer bg-transparent border-none"
                              />
                              <span className="text-sm font-mono">{config.textColor}</span>
                           </div>
                        </div>
                    </div>
                 </div>

                 <div className="bg-[#1f1f1f] p-6 rounded-lg border border-gray-800">
                    <h3 className="text-lg font-bold mb-4 flex items-center gap-2"><ImageIcon size={20}/> Marca e Identidad</h3>
                    <div className="space-y-4">
                       <div>
                          <label className="block text-xs text-gray-400 uppercase mb-2">Nombre de la App</label>
                          <input 
                             type="text" 
                             value={config.appName}
                             onChange={(e) => handleConfigChange('appName', e.target.value)}
                             className="w-full bg-[#2a2a2a] border border-gray-700 rounded p-3 text-white focus:outline-none focus:border-white transition"
                          />
                       </div>
                       <div>
                          <label className="block text-xs text-gray-400 uppercase mb-2">URL del Logo (Opcional)</label>
                          <input 
                             type="text" 
                             value={config.logoUrl}
                             onChange={(e) => handleConfigChange('logoUrl', e.target.value)}
                             className="w-full bg-[#2a2a2a] border border-gray-700 rounded p-3 text-white text-sm focus:outline-none focus:border-white transition"
                             placeholder="https://..."
                          />
                       </div>
                    </div>
                 </div>

                 {/* Layout Settings */}
                 <div className="bg-[#1f1f1f] p-6 rounded-lg border border-gray-800">
                    <h3 className="text-lg font-bold mb-4 flex items-center gap-2"><Layout size={20}/> Estructura y Orden</h3>
                    
                    <div className="flex items-center justify-between p-4 bg-[#2a2a2a] rounded mb-4">
                       <span>Mostrar Billboard Principal</span>
                       <button 
                         onClick={() => handleConfigChange('showBillboard', !config.showBillboard)}
                         className={`w-12 h-6 rounded-full transition relative ${config.showBillboard ? 'bg-green-500' : 'bg-gray-600'}`}
                       >
                          <span className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${config.showBillboard ? 'left-7' : 'left-1'}`} />
                       </button>
                    </div>

                    <div className="space-y-2">
                       <label className="block text-xs text-gray-400 uppercase mb-2">Orden de Categorías (Home)</label>
                       {config.categoryOrder.map((catId, index) => {
                          const def = categoryDefs[catId];
                          if(!def) return null;
                          return (
                             <div key={catId} className="flex items-center justify-between p-3 bg-[#2a2a2a] rounded border border-gray-700">
                                <span>{def.title}</span>
                                <div className="flex gap-1">
                                   <button 
                                     disabled={index === 0}
                                     onClick={() => moveCategory(index, 'up')}
                                     className="p-1 hover:bg-white/10 rounded disabled:opacity-30"
                                   >
                                      <ArrowUp size={18} />
                                   </button>
                                   <button 
                                     disabled={index === config.categoryOrder.length - 1}
                                     onClick={() => moveCategory(index, 'down')}
                                     className="p-1 hover:bg-white/10 rounded disabled:opacity-30"
                                   >
                                      <ArrowDown size={18} />
                                   </button>
                                </div>
                             </div>
                          );
                       })}
                    </div>
                 </div>
              </div>

              {/* Right Column: AI Assistant */}
              <div className="bg-[#1f1f1f] border border-gray-800 rounded-lg flex flex-col h-[600px] xl:h-auto overflow-hidden relative shadow-2xl">
                  <div className="p-4 bg-gradient-to-r from-purple-900 to-blue-900 flex items-center gap-3 border-b border-white/10">
                      <div className="bg-white/20 p-2 rounded-full">
                          <Bot size={24} className="text-white" />
                      </div>
                      <div>
                          <h3 className="font-bold text-white">NetClone AI Architect</h3>
                          <p className="text-xs text-blue-200">Modifica la app usando lenguaje natural</p>
                      </div>
                      <Sparkles className="ml-auto text-yellow-300 animate-pulse" />
                  </div>

                  {/* Chat Messages */}
                  <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-[#181818]">
                      {chatHistory.map((msg, idx) => (
                          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                              <div className={`max-w-[85%] p-3 rounded-lg text-sm leading-relaxed ${
                                  msg.role === 'user' 
                                  ? 'bg-blue-600 text-white rounded-tr-none' 
                                  : 'bg-[#2a2a2a] text-gray-200 rounded-tl-none border border-gray-700'
                              }`}>
                                  {msg.text}
                              </div>
                          </div>
                      ))}
                      {isAiLoading && (
                          <div className="flex justify-start">
                              <div className="bg-[#2a2a2a] p-3 rounded-lg rounded-tl-none border border-gray-700 flex items-center gap-2">
                                  <Loader2 size={16} className="animate-spin text-purple-400" />
                                  <span className="text-xs text-gray-400">Procesando cambios...</span>
                              </div>
                          </div>
                      )}
                      <div ref={chatEndRef} />
                  </div>

                  {/* Input Area */}
                  <form onSubmit={handleAiSubmit} className="p-4 bg-[#1f1f1f] border-t border-gray-800 flex gap-2">
                      <input 
                        type="text" 
                        value={chatInput}
                        onChange={(e) => setChatInput(e.target.value)}
                        placeholder="Ej: 'Cambia el color a rosado Barbie' o 'Agrega Matrix'"
                        className="flex-1 bg-[#121212] border border-gray-700 rounded-full px-4 py-3 focus:outline-none focus:border-blue-500 text-sm transition"
                        disabled={isAiLoading}
                      />
                      <button 
                        type="submit" 
                        disabled={isAiLoading || !chatInput.trim()}
                        className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white p-3 rounded-full transition shadow-lg"
                      >
                          <Send size={20} />
                      </button>
                  </form>
              </div>
           </div>
        )}

        {/* --- EDIT MOVIE FORM --- */}
        {activeTab === 'edit' && editingMovie && (
           <div className="max-w-2xl mx-auto">
               <button onClick={() => setActiveTab('content')} className="mb-4 text-gray-400 hover:text-white">&larr; Volver a la lista</button>
               <div className="bg-[#1f1f1f] p-6 rounded-lg border border-gray-800 space-y-4">
                  <h2 className="text-xl font-bold mb-4">Editar: {editingMovie.title || 'Nuevo Título'}</h2>
                  
                  <div className="space-y-4">
                     <input 
                       className="w-full bg-[#2a2a2a] border border-gray-700 p-3 rounded text-white" 
                       placeholder="Título"
                       value={editingMovie.title}
                       onChange={(e) => handleMovieChange('title', e.target.value)}
                     />
                     <textarea 
                       className="w-full bg-[#2a2a2a] border border-gray-700 p-3 rounded text-white" 
                       placeholder="Descripción"
                       rows={3}
                       value={editingMovie.description}
                       onChange={(e) => handleMovieChange('description', e.target.value)}
                     />
                     <div className="grid grid-cols-2 gap-4">
                        <input 
                           type="number" 
                           className="bg-[#2a2a2a] border border-gray-700 p-2 rounded text-white" 
                           placeholder="Año"
                           value={editingMovie.year}
                           onChange={(e) => handleMovieChange('year', parseInt(e.target.value))}
                        />
                        <input 
                           className="bg-[#2a2a2a] border border-gray-700 p-2 rounded text-white" 
                           placeholder="Duración (e.g. 2h 10m)"
                           value={editingMovie.duration}
                           onChange={(e) => handleMovieChange('duration', e.target.value)}
                        />
                     </div>
                     
                     <div className="space-y-2">
                        <p className="text-xs text-gray-400 uppercase flex items-center gap-2">
                           <ImageIcon size={14}/> Imágenes
                        </p>
                        <input 
                           className="w-full bg-[#2a2a2a] border border-gray-700 p-2 rounded text-white text-sm" 
                           placeholder="Poster Vertical URL"
                           value={editingMovie.posterUrl}
                           onChange={(e) => handleMovieChange('posterUrl', e.target.value)}
                        />
                        <input 
                           className="w-full bg-[#2a2a2a] border border-gray-700 p-2 rounded text-white text-sm" 
                           placeholder="Cover Horizontal URL"
                           value={editingMovie.coverUrl}
                           onChange={(e) => handleMovieChange('coverUrl', e.target.value)}
                        />
                     </div>

                     <div className="space-y-2">
                        <p className="text-xs text-gray-400 uppercase flex items-center gap-2">
                           <Video size={14}/> Video Player
                        </p>
                        <input 
                           className="w-full bg-[#2a2a2a] border border-gray-700 p-2 rounded text-white text-sm" 
                           placeholder="URL del Video (iframe source)"
                           value={editingMovie.videoUrl || ''}
                           onChange={(e) => handleMovieChange('videoUrl', e.target.value)}
                        />
                     </div>
                  </div>
                  
                  <button onClick={handleSaveMovie} className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded mt-4 flex items-center justify-center gap-2">
                     <Save size={20} /> Guardar Película
                  </button>
               </div>
           </div>
        )}
      </div>
    </div>
  );
};

const SettingsIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.09a2 2 0 0 1-1-1.74v-.47a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.39a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>
);