import React, { useState, useEffect } from 'react';
import { Search as SearchIcon, Loader2 } from 'lucide-react';
import { searchMoviesWithAI } from '../services/geminiService';
import { Movie } from '../types';
import { MovieCard } from './MovieCard';

interface SearchProps {
  onMovieClick: (movie: Movie) => void;
  onClose: () => void;
}

export const Search: React.FC<SearchProps> = ({ onMovieClick, onClose }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Movie[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [debouncedQuery, setDebouncedQuery] = useState('');

  // Debounce search input
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(query);
    }, 800);

    return () => clearTimeout(timer);
  }, [query]);

  // Trigger AI search
  useEffect(() => {
    const fetchResults = async () => {
      if (debouncedQuery.length < 3) return;
      
      setIsLoading(true);
      const movies = await searchMoviesWithAI(debouncedQuery);
      setResults(movies);
      setIsLoading(false);
    };

    fetchResults();
  }, [debouncedQuery]);

  return (
    <div className="min-h-screen bg-[#141414] pt-24 px-4 md:px-12 animate-fade-in">
       <div className="flex items-center gap-4 mb-8 border-b border-gray-700 pb-4">
          <SearchIcon className="text-gray-400 h-8 w-8" />
          <input 
            type="text"
            placeholder="Títulos, personas, géneros (Powered by Gemini AI)..."
            className="bg-transparent w-full text-2xl md:text-4xl text-white focus:outline-none placeholder-gray-600 font-medium"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
          />
          {isLoading && <Loader2 className="animate-spin text-red-600 h-8 w-8" />}
       </div>

       {query.length > 0 && query.length < 3 && (
         <p className="text-gray-500 text-center mt-10">Escribe al menos 3 caracteres para buscar.</p>
       )}

       {!isLoading && results.length === 0 && query.length >= 3 && debouncedQuery && (
          <div className="text-center mt-20">
            <p className="text-white text-xl">No se encontraron resultados para "{query}"</p>
            <p className="text-gray-500 mt-2">Intenta con otros términos. Gemini intentará encontrar coincidencias conceptuales.</p>
          </div>
       )}

       <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-x-4 gap-y-8">
          {results.map((movie) => (
             <div key={movie.id} className="w-full">
               <MovieCard movie={movie} onClick={onMovieClick} />
               <p className="text-gray-300 text-sm mt-2 font-medium truncate">{movie.title}</p>
             </div>
          ))}
       </div>
    </div>
  );
};