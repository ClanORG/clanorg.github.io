import React from 'react';
import { Home, Search, PlaySquare, UserSquare2 } from 'lucide-react';
import { ViewState, AppConfig } from '../types';

interface BottomNavProps {
  viewState: ViewState;
  setViewState: (state: ViewState) => void;
  config: AppConfig;
}

export const BottomNav: React.FC<BottomNavProps> = ({ viewState, setViewState, config }) => {
  const navItems = [
    { id: ViewState.HOME, label: 'Inicio', icon: Home },
    { id: ViewState.SEARCH, label: 'Buscar', icon: Search },
    { id: ViewState.NEW_HOT, label: 'Nuevo', icon: PlaySquare },
    { id: ViewState.MY_LIST, label: 'Mi Netflix', icon: UserSquare2 },
  ];

  return (
    <div 
      className="md:hidden fixed bottom-0 left-0 w-full border-t z-50 backdrop-blur-md pb-safe"
      style={{ backgroundColor: config.backgroundColor + 'E6', borderColor: config.secondaryColor }} // E6 = 90% opacity
    >
      <div className="flex justify-around items-center h-[60px] pb-2 pt-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = viewState === item.id;
          return (
            <button 
              key={item.id}
              onClick={() => setViewState(item.id)}
              className={`flex flex-col items-center justify-center gap-1 w-full h-full transition-colors`}
              style={{ color: isActive ? config.textColor : '#808080' }}
            >
              <div className="relative">
                <Icon size={24} strokeWidth={isActive ? 2.5 : 2} />
                {item.id === ViewState.NEW_HOT && (
                  <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full border border-black" style={{ backgroundColor: config.primaryColor }}></span>
                )}
              </div>
              <span className="text-[10px] font-medium tracking-wide">{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};