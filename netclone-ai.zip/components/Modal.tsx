import React from 'react';
import { X, Play, Plus, ThumbsUp, Send, Download } from 'lucide-react';
import { Movie } from '../types';

interface ModalProps {
  movie: Movie | null;
  onClose: () => void;
  onPlay: (movie: Movie) => void;
}

export const Modal: React.FC<ModalProps> = ({ movie, onClose, onPlay }) => {
  if (!movie) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-end md:items-center justify-center bg-black/60 backdrop-blur-[2px] animate-fade-in" onClick={onClose}>
      {/* Container: Bottom Sheet on Mobile, Center Modal on Desktop */}
      <div 
        onClick={(e) => e.stopPropagation()} 
        className="relative w-full md:w-[900px] h-[85vh] md:h-auto md:max-h-[95vh] bg-[#121212] md:rounded-xl rounded-t-2xl shadow-2xl overflow-y-auto no-scrollbar animate-slide-up md:animate-scale-up flex flex-col"
      >
        
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-3 right-3 z-50 h-8 w-8 md:h-10 md:w-10 rounded-full bg-[#181818]/50 flex items-center justify-center hover:bg-gray-800 transition text-white"
        >
          <X className="w-5 md:w-6" />
        </button>

        {/* Hero Image Section */}
        <div className="relative h-56 md:h-[450px] w-full shrink-0">
          <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-transparent to-transparent z-10" />
          <img 
            src={movie.coverUrl} 
            alt={movie.title} 
            className="w-full h-full object-cover"
          />
          
          <div className="absolute bottom-0 left-0 w-full p-4 md:p-10 z-20 space-y-2 hidden md:block">
             <h2 className="text-4xl font-extrabold text-white">{movie.title}</h2>
          </div>
        </div>

        {/* Mobile Content Body */}
        <div className="px-4 md:px-12 pb-24 md:pb-8 bg-[#121212] md:-mt-10 relative z-20">
          
          {/* Mobile Title & Meta */}
          <div className="md:hidden mb-4">
             <h2 className="text-2xl font-bold text-white mb-2">{movie.title}</h2>
             <div className="flex items-center gap-3 text-gray-400 text-xs">
                <span className="text-green-400 font-bold">{movie.matchScore}% para ti</span>
                <span className="bg-gray-800 px-1 rounded text-gray-300">{movie.year}</span>
                <span className="bg-gray-800 px-1 rounded text-gray-300">{movie.rating}</span>
                <span>{movie.duration}</span>
                <span className="border border-gray-600 px-1 rounded text-[10px]">HD</span>
             </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3 mb-6">
             <button 
               onClick={() => onPlay(movie)}
               className="w-full bg-white text-black py-2.5 rounded flex items-center justify-center gap-2 font-bold text-lg hover:bg-gray-200 transition"
             >
                <Play fill="black" size={24} /> Reproducir
             </button>
             
             <button className="w-full bg-[#262626] text-white py-2.5 rounded flex items-center justify-center gap-2 font-semibold text-sm hover:bg-[#333] transition">
                <Download size={20} /> Descargar
             </button>
          </div>

          <p className="text-white text-sm md:text-lg leading-relaxed mb-4 text-gray-200">
            {movie.description}
          </p>
          
          <div className="text-xs text-gray-400 mb-6 space-y-1">
             <p><span className="text-gray-500">Elenco:</span> Actor Uno, Actor Dos, Actriz Tres</p>
             <p><span className="text-gray-500">Géneros:</span> {movie.genre.join(', ')}</p>
          </div>

          {/* Interaction Row */}
          <div className="flex items-start justify-between px-4 pb-6 border-b border-gray-800 mb-6">
             <button className="flex flex-col items-center gap-1 text-white opacity-80 hover:opacity-100">
               <Plus size={24} />
               <span className="text-[10px]">Mi lista</span>
             </button>
             <button className="flex flex-col items-center gap-1 text-white opacity-80 hover:opacity-100">
               <ThumbsUp size={24} />
               <span className="text-[10px]">Calificar</span>
             </button>
             <button className="flex flex-col items-center gap-1 text-white opacity-80 hover:opacity-100">
               <Send size={24} />
               <span className="text-[10px]">Compartir</span>
             </button>
          </div>

          {/* More Like This */}
          <h3 className="text-base font-bold text-white mb-4 border-l-4 border-red-600 pl-2">Más títulos similares</h3>
          <div className="grid grid-cols-3 gap-2">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => (
                <div key={i} className="bg-[#1f1f1f] rounded overflow-hidden cursor-pointer relative aspect-[2/3]">
                   <img 
                    src={`https://picsum.photos/seed/${movie.id + i}/300/450`} 
                    alt="Similar" 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-1 right-1 bg-black/60 px-1 rounded text-[9px] font-bold text-white">
                     {movie.year}
                  </div>
                </div>
            ))}
          </div>

        </div>
      </div>
    </div>
  );
};