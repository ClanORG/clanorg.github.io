import React, { useEffect, useState } from 'react';
import { Search, Bell, Cast, Settings } from 'lucide-react';
import { ViewState, AppConfig } from '../types';

interface NavbarProps {
  setViewState: (state: ViewState) => void;
  onSearchClick: () => void;
  config: AppConfig;
}

export const Navbar: React.FC<NavbarProps> = ({ setViewState, onSearchClick, config }) => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav 
      className={`fixed w-full z-40 transition-all duration-300 ${isScrolled ? 'shadow-md' : ''}`}
      style={{ 
         backgroundColor: isScrolled ? config.backgroundColor + 'F2' : 'transparent', // F2 = 95% opacity
         backgroundImage: isScrolled ? 'none' : `linear-gradient(to bottom, ${config.backgroundColor}CC, transparent)`
      }}
    >
      
      {/* Top Bar: Logo + Icons */}
      <div className="px-4 md:px-12 py-3 flex items-center justify-between">
        
        {/* Left Side: Logo */}
        <div className="flex items-center gap-8">
          {config.logoUrl ? (
            <>
              <img 
                src={config.logoUrl} 
                alt="Logo Mobile" 
                className="h-9 md:hidden cursor-pointer object-contain drop-shadow-md"
                onClick={() => setViewState(ViewState.HOME)}
              />
              <img 
                src={config.logoUrl}
                alt="Logo Desktop" 
                className="hidden md:block h-7 cursor-pointer"
                onClick={() => setViewState(ViewState.HOME)}
              />
            </>
          ) : (
             <h1 
              onClick={() => setViewState(ViewState.HOME)}
              className="text-red-600 font-bold text-2xl md:text-3xl tracking-tighter cursor-pointer"
              style={{ color: config.primaryColor }}
             >
                {config.appName}
             </h1>
          )}

          {/* Desktop Links */}
          <div className="hidden md:flex gap-6 text-sm font-medium opacity-90">
            <span onClick={() => setViewState(ViewState.HOME)} className="cursor-pointer hover:opacity-100 transition">Inicio</span>
            <span className="cursor-pointer hover:opacity-100 transition">Series</span>
            <span className="cursor-pointer hover:opacity-100 transition">Películas</span>
            <span className="cursor-pointer hover:opacity-100 transition">Novedades populares</span>
            <span onClick={() => setViewState(ViewState.MY_LIST)} className="cursor-pointer hover:opacity-100 transition">Mi lista</span>
          </div>
        </div>

        {/* Right Side Icons */}
        <div className="flex items-center gap-5">
           <div className="md:hidden cursor-pointer hover:opacity-80">
              <Cast size={24} />
           </div>
           
           <div className="cursor-pointer hover:opacity-80" onClick={onSearchClick}>
            <Search size={24} />
          </div>

          {/* Admin Panel Link */}
          <div className="cursor-pointer hover:opacity-80" onClick={() => setViewState(ViewState.ADMIN)}>
             <Settings size={24} />
          </div>

          <div className="hidden sm:block cursor-pointer hover:opacity-80">
            <Bell size={24} />
          </div>

          <div className="flex items-center gap-2 cursor-pointer group">
            <div className="w-7 h-7 md:w-8 md:h-8 rounded flex items-center justify-center overflow-hidden border border-transparent group-hover:border-white transition" style={{ backgroundColor: 'blue' }}>
                <img src="https://picsum.photos/seed/user/100/100" alt="User" />
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Filter Pills (Sub-header) */}
      <div className={`md:hidden flex items-center gap-3 px-4 pb-4 overflow-x-auto no-scrollbar transition-all duration-300 ${isScrolled ? '-mt-2 pb-2' : ''}`}>
          <button className="px-4 py-1.5 rounded-full border border-current bg-transparent backdrop-blur-sm text-sm font-normal whitespace-nowrap opacity-90">Series</button>
          <button className="px-4 py-1.5 rounded-full border border-current bg-transparent backdrop-blur-sm text-sm font-normal whitespace-nowrap opacity-90">Películas</button>
          <button className="px-4 py-1.5 rounded-full border border-current bg-transparent backdrop-blur-sm text-sm font-normal whitespace-nowrap opacity-90">Categorías</button>
      </div>
    </nav>
  );
};