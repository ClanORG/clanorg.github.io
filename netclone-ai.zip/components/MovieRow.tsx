import React, { useRef } from 'react';
import { Movie } from '../types';
import { MovieCard } from './MovieCard';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface MovieRowProps {
  title: string;
  movies: Movie[];
  onMovieClick: (movie: Movie) => void;
}

export const MovieRow: React.FC<MovieRowProps> = ({ title, movies, onMovieClick }) => {
  const rowRef = useRef<HTMLDivElement>(null);

  const handleScroll = (direction: 'left' | 'right') => {
    if (rowRef.current) {
      const { scrollLeft, clientWidth } = rowRef.current;
      const scrollTo = direction === 'left' 
        ? scrollLeft - clientWidth / 2 
        : scrollLeft + clientWidth / 2;
      
      rowRef.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
    }
  };

  return (
    <div className="px-4 md:px-12 mt-4 space-y-2 group relative">
      <h2 className="text-white text-md md:text-xl lg:text-2xl font-semibold mb-4 cursor-pointer hover:text-gray-300 transition w-fit">
        {title}
      </h2>
      
      <div className="relative group">
        <div 
          className="hidden group-hover:flex absolute top-0 bottom-0 left-0 z-40 w-12 bg-black/50 hover:bg-black/70 cursor-pointer items-center justify-center transition"
          onClick={() => handleScroll('left')}
        >
          <ChevronLeft className="text-white h-8 w-8" />
        </div>

        <div 
          ref={rowRef}
          className="flex items-center gap-2 overflow-x-scroll no-scrollbar scroll-smooth py-4"
        >
          {movies.map((movie) => (
            <MovieCard key={movie.id} movie={movie} onClick={onMovieClick} />
          ))}
        </div>

        <div 
          className="hidden group-hover:flex absolute top-0 bottom-0 right-0 z-40 w-12 bg-black/50 hover:bg-black/70 cursor-pointer items-center justify-center transition"
          onClick={() => handleScroll('right')}
        >
          <ChevronRight className="text-white h-8 w-8" />
        </div>
      </div>
    </div>
  );
};