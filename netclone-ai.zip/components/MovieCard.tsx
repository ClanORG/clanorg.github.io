import React from 'react';
import { Movie } from '../types';
import { Play, Plus, ThumbsUp, ChevronDown } from 'lucide-react';

interface MovieCardProps {
  movie: Movie;
  onClick: (movie: Movie) => void;
}

export const MovieCard: React.FC<MovieCardProps> = ({ movie, onClick }) => {
  return (
    <div className="group relative flex-none snap-start cursor-pointer transition z-0 hover:z-50 w-[110px] md:w-[200px] aspect-[2/3]">
      
      {/* Vertical Poster (Mobile App Style) */}
      <img
        onClick={() => onClick(movie)}
        src={movie.posterUrl}
        alt={movie.title}
        className="cursor-pointer object-cover w-full h-full rounded-md md:rounded-lg shadow-lg hover:brightness-110 transition"
      />

      {/* Desktop Hover Card (Hidden on Mobile) */}
      <div className="hidden md:block opacity-0 absolute top-0 duration-300 z-50 invisible md:visible delay-500 w-[150%] -left-[25%] scale-95 group-hover:scale-110 group-hover:-translate-y-10 group-hover:opacity-100 transition shadow-2xl bg-[#181818] rounded-lg overflow-hidden ring-1 ring-white/20">
        
        <div className="relative w-full h-36">
           <img
            src={movie.thumbnailUrl} // Switch to landscape for the details view
            alt={movie.title}
            className="cursor-pointer object-cover w-full h-full"
          />
        </div>

        <div className="p-4 bg-[#181818] w-full shadow-md rounded-b-lg">
          <div className="flex flex-row items-center gap-2 mb-3">
            <div 
              className="cursor-pointer w-8 h-8 bg-white rounded-full flex justify-center items-center transition hover:bg-neutral-300"
              onClick={() => {}}
            >
              <Play className="text-black w-4 ml-0.5" fill="black" />
            </div>
            <div className="cursor-pointer w-8 h-8 border-2 border-gray-500 rounded-full flex justify-center items-center transition hover:border-white">
              <Plus className="text-gray-300 w-4" />
            </div>
            <div className="cursor-pointer w-8 h-8 border-2 border-gray-500 rounded-full flex justify-center items-center transition hover:border-white">
              <ThumbsUp className="text-gray-300 w-4" />
            </div>
            <div 
              onClick={() => onClick(movie)}
              className="cursor-pointer ml-auto w-8 h-8 border-2 border-gray-500 rounded-full flex justify-center items-center transition hover:border-white"
            >
              <ChevronDown className="text-gray-300 w-4" />
            </div>
          </div>

          <p className="text-green-400 font-bold text-xs mb-2">
            {movie.matchScore}% para ti
          </p>

          <div className="flex flex-row items-center gap-2 text-[10px] text-white font-medium mb-2">
            <span className="border border-gray-500 px-1 rounded-sm text-gray-400">16+</span>
            <span>{movie.duration}</span>
            <span className="border border-gray-500 px-1 text-[8px] rounded-sm text-gray-400">HD</span>
          </div>
          
          <div className="flex flex-row items-center gap-2 text-[10px] text-gray-300">
            <p>{movie.genre.slice(0, 3).join(' • ')}</p>
          </div>
        </div>
      </div>
    </div>
  );
};